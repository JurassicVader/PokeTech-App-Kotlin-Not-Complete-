package com.example.pokedex

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun pokedexfunc(view: View) {
        var intent = Intent(this, Pokedex::class.java)
        startActivity(intent)
    }

    fun settingsfunc(view: View) {
        var intent = Intent(this, Settings::class.java)
        startActivity(intent)
    }

    fun tutorialfunc(view: View) {
        var intent = Intent(this, Tutorial::class.java)
        startActivity(intent)
    }

}
