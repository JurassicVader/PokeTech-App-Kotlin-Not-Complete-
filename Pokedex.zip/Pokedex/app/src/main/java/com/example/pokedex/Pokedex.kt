package com.example.pokedex

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Pokedex : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pokedex)
    }
}